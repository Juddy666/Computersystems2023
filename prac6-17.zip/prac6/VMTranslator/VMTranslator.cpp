#include <string>

#include "VMTranslator.h"

using namespace std;

/**
 * VMTranslator constructor
 */
VMTranslator::VMTranslator() {
    // Your code here
}

/**
 * VMTranslator destructor
 */
VMTranslator::~VMTranslator() {
    // Your code here
}

/** Generate Hack Assembly code for a VM push operation */
string VMTranslator::vm_push(string segment, int offset){
    string code;

    if (segment == "constant") {                                              // load value into D register
        code = "@" + std::to_string(offset) + "\n" +     
               "D=A\n";
    } else if (segment == "local" || segment == "argument" || segment == "this" || segment == "that") {    // local argument this that segments
        string pointer;
        if (segment == "local") pointer = "LCL";
        else if (segment == "argument") pointer = "ARG";
        else if (segment == "this") pointer = "THIS";
        else if (segment == "that") pointer = "THAT";

        code = "@" + std::to_string(offset) + "\n" +           // calculate the address base address + offset
               "D=A\n" +
               "@" + pointer + "\n" +
               "A=M+D\n" +
               "D=M\n";



    } else if (segment == "pointer" || segment == "temp") {   // pointer and temp segments
        int base_address;
        if (segment == "pointer") {
            base_address = 3;
        } else { 
            base_address = 5;
        }
        code = "@" + std::to_string(base_address + offset) + "\n" +
               "D=M\n";
    } 
    
    
    
    else if (segment == "static") {             //static
        code = "@static." + std::to_string(offset) + "\n" +
               "D=M\n";
    }

                                            // push D to stack
    code += "@SP\n";
    code += "A=M\n";
    code += "M=D\n" ;
    code += "@SP\n" ;
    code += "M=M+1\n";

    return code;
    }

/** Generate Hack Assembly code for a VM pop operation */
string VMTranslator::vm_pop(string segment, int offset){    
        string code;
     // local argument this that 
    if (segment == "local" || segment == "argument" || segment == "this" || segment == "that") {
        string pointer;
        if (segment == "local") pointer = "LCL";
        else if (segment == "argument") pointer = "ARG";
        else if (segment == "this") pointer = "THIS";
        else if (segment == "that") pointer = "THAT";

        code = "@" + std::to_string(offset) + "\n" +       // find the target memory address base and offset
               "D=A\n" +
               "@" + pointer + "\n" +
               "D=M+D\n" +
               "@R13\n" + 
               "M=D\n" +
               "@SP\n" +
               "AM=M-1\n" + 
               "D=M\n" +
               "@R13\n" +
               "A=M\n" +
               "M=D\n"; 
    } 
    
    
    else if (segment == "pointer" || segment == "temp") {  //pointer and temp
        int base_address;
        if (segment == "pointer") {
            base_address = 3;
        } else { 
            base_address = 5;
        }
        code = "@SP\n";
        code += "AM=M-1\n";
        code += "D=M\n";
        code += "@" + std::to_string(base_address + offset) + "\n";
        code += "M=D\n";


        //static
    } else if (segment == "static") {
        code = "@SP\n";
        code += "AM=M-1\n";
        code += "D=M\n";
        code += "@static." + std::to_string(offset) + "\n";
        code += "M=D\n";
    }

    return code;
}

/** Generate Hack Assembly code for a VM add operation */
string VMTranslator::vm_add(){
    string assemblyCode;
    
    assemblyCode += "@SP\n";                // Load the stack pointer
    assemblyCode += "AM=M-1\n";             // Decrement the stack pointer and set the address to the top of the stack
    assemblyCode += "D=M\n";                // Store the second value from the top of the stack in D
    assemblyCode += "A=A-1\n";              // Set the address to the first value from the top of the stack
    assemblyCode += "M=M+D\n";              // Add the second value (D) to the first value and store the result in the first value
    
    return assemblyCode;
}

/** Generate Hack Assembly code for a VM sub operation */
string VMTranslator::vm_sub(){
    return "";
}

/** Generate Hack Assembly code for a VM neg operation */
string VMTranslator::vm_neg(){  
    return "";
}

/** Generate Hack Assembly code for a VM eq operation */
string VMTranslator::vm_eq(){
    return "";
}

/** Generate Hack Assembly code for a VM gt operation */
string VMTranslator::vm_gt(){
    return "";
}

/** Generate Hack Assembly code for a VM lt operation */
string VMTranslator::vm_lt(){
    return "";
}

/** Generate Hack Assembly code for a VM and operation */
string VMTranslator::vm_and(){
        string assemblyCode;

    assemblyCode += "@SP\n";        
    assemblyCode += "AM=M-1\n";    
    assemblyCode += "D=M\n";        // store the second value in D
    assemblyCode += "A=A-1\n";      // Set the address to the first value
    assemblyCode += "M=D&M\n";      //AND on the values and store the result back to the stack

    return assemblyCode;
}

/** Generate Hack Assembly code for a VM or operation */
string VMTranslator::vm_or(){
    return "";
}

/** Generate Hack Assembly code for a VM not operation */
string VMTranslator::vm_not(){
      string assemblyCode;

    assemblyCode += "@SP\n";       
    assemblyCode += "A=M-1\n";      
    assemblyCode += "M=!M\n";       //  not/invert on the value at the top of the stack

    return assemblyCode;
}

/** Generate Hack Assembly code for a VM label operation */
string VMTranslator::vm_label(string label){
    return "(" + label + ")\n";
}

/** Generate Hack Assembly code for a VM goto operation */
string VMTranslator::vm_goto(string label){
        return "@" + label + "\n0;JMP";
}

/** Generate Hack Assembly code for a VM if-goto operation */
string VMTranslator::vm_if(string label){
      return std::string("@SP\n") +
           std::string("AM=M-1\n") +
           std::string("D=M\n") +
           std::string("@") + label + "\n" +
           std::string("D;JNE");
          
          
}

/** Generate Hack Assembly code for a VM function operation */
string VMTranslator::vm_function(string function_name, int n_vars){
        string function_label = function_name + "$" + function_name;
    string ASMcode = "(" + function_label + ")\n";  // Generate function label

    for (int i = 0; i < n_vars; i++) {
        ASMcode += "@SP\n";    // Push 0 to the stack for each local variable
        ASMcode += "A=M\n";
        ASMcode += "M=0\n";
        ASMcode +=  "@SP\n";
        ASMcode += "M=M+1\n";
    }

    return ASMcode;
}

/** Generate Hack Assembly code for a VM call operation */
string VMTranslator::vm_call(string function_name, int n_args){
  string code;
  return code;
}

/** Generate Hack Assembly code for a VM return operation */
string VMTranslator::vm_return(){
    string code = "@LCL\n";          // Store endFrame = LCL

    return code;
}